package com.theblock.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    // Ganti URL ini setelah website TheBlox dipublikasikan melalui GitHub Pages.
    private static final String GAME_URL = "https://YOUR-USERNAME.github.io/TheBlox/";

    private FrameLayout root;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        showSplash();
        root.postDelayed(this::openGame, 2200);
    }

    private void showSplash() {
        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(Color.WHITE);

        LinearLayout logo = new LinearLayout(this);
        logo.setGravity(Gravity.CENTER);
        logo.setOrientation(LinearLayout.HORIZONTAL);

        addWord(logo, "T", 43);
        addWord(logo, "he", 27);
        addWord(logo, "B", 43);
        addWord(logo, "l", 27);

        TextView blockO = new TextView(this);
        blockO.setText("■");
        blockO.setTextColor(Color.BLACK);
        blockO.setTextSize(27);
        blockO.setRotation(15);
        logo.addView(blockO);

        addWord(logo, "ck", 27);
        splash.addView(logo);

        TextView loading = new TextView(this);
        loading.setText("Loading...");
        loading.setTextColor(Color.BLACK);
        loading.setTextSize(17);
        loading.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        loading.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
        );
        lp.bottomMargin = dp(48);
        root.addView(splash, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));
        root.addView(loading, lp);
    }

    private void addWord(LinearLayout parent, String value, int size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.BLACK);
        t.setTextSize(size);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        parent.addView(t);
    }

    private void openGame() {
        root.removeAllViews();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        root.addView(webView, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ));

        if (GAME_URL.contains("YOUR-USERNAME")) {
            TextView message = new TextView(this);
            message.setText("TheBlox berhasil dibuka!\\n\\nPublikasikan website di GitHub Pages, lalu ganti GAME_URL di MainActivity.java dengan alamat website kamu.");
            message.setTextColor(Color.BLACK);
            message.setTextSize(17);
            message.setGravity(Gravity.CENTER);
            message.setPadding(dp(28), dp(28), dp(28), dp(28));
            root.addView(message, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ));
        } else {
            webView.loadUrl(GAME_URL);
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
