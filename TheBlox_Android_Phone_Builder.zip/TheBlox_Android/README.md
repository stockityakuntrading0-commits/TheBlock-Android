# TheBlox Android starter (build APK from your phone)

This is an Android WebView wrapper starter. The app opens with a white TheBlock-style splash screen, then opens the hosted TheBlox website.

## Important
The splash screen is native Android UI. The actual game website must be published separately (for example, with GitHub Pages). This starter is not yet a 3D game or multiplayer engine.

## Phone-only workflow
1. Download and extract this ZIP on your Android phone.
2. Create a GitHub repository named `TheBlox-Android`.
3. Upload all files and folders from this project to the repository root. Make sure `.github/workflows/build-apk.yml` is included.
4. In `app/src/main/java/com/theblock/app/MainActivity.java`, replace `https://YOUR-USERNAME.github.io/TheBlox/` with your real GitHub Pages website URL.
5. Commit the change to the `main` branch.
6. Open the repository on GitHub, select **Actions**, then **Build TheBlox APK**.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, scroll to **Artifacts**, and download `TheBlox-debug-apk`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install (Android may ask permission to install from that source).

## Build notes
- GitHub Actions builds the APK in the cloud, so Android Studio or a PC is not required.
- The first APK is a debug build for testing. A release APK for public distribution should later be signed with a private release key.
